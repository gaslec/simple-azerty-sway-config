# -*- coding: utf-8 -*-
__license__   = 'GPL v3'
__copyright__ = '2016,2017,2018,2019,2020,2021,2022 DaltonST'
__my_version__ = "1.0.191"  #Qt6

from polyglot.builtins import as_unicode

#------------------------------------------------------------------------------------------------------
def log_heading_common(log,s1,s2,s3,s4,s5):

    import time
    localtime = time.asctime( time.localtime(time.time()) )
    log(localtime)

    import platform
    log("Python: " + platform.system() + "   " + platform.python_implementation() + "   " + platform.python_version())

    if s1:
        s1 = as_unicode(s1)
        log(s1)       #usually SQLite version

    if s2:              #usually PRAGMA statement
        if as_unicode(s2) == as_unicode("") :
            s2 = ""
            log(s2)
            log(" ")
            log("═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════")
        else:
            log(s2)
            log(" ")

    if s3:
        log(s3)        #usually "Beginning ...."

    if s4:
        log(s4)        #optional

    if s5:
        log(s5)        #optional

    log("═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════")

#END heading.py